#ifndef  __BEEP_H
#define __BEEP_H
void Beep_Off(void);
void Beep_On(void);
void Beep_Turn(void);
void Beep_Init(void);
#endif
